                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3559349
spotmini bostondynamics robot dog by Era3 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

https://www.youtube.com/watch?v=IUXAPo_Kj-0
https://www.youtube.com/watch?v=7A--OgBd9KU
https://www.youtube.com/watch?v=FTiyuoW0_vo
Spotmicro - robot dog
by KDY0523 Thank you Kim

# Özel bölüm

<iframe src="//www.youtube.com/embed/7A--OgBd9KU" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/FTiyuoW0_vo" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/IUXAPo_Kj-0" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/saOiuGGN4Cc" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/GKfEr5FNdcc" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/mCxjQMm8QL8" frameborder="0" allowfullscreen></iframe>
Yeni motorsuz bacak tasarımı

<iframe src="//www.youtube.com/embed/mZ6pgFkfnoU" frameborder="0" allowfullscreen></iframe>